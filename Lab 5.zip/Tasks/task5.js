let num=prompt("Enter a number: ");

if(num%3==0)
{
    console.log("The number you entered is multiple of 3!");
}

else
{
    console.log("The number you entered is not a multiple of 3");
}
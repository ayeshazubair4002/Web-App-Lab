const Profile=
{
    username: "ayeshazubairafzal",
    profileName: "Ayesha Zubair ",
    followers:161,
    following:180,
    posts: 0,
}


console.log("Username: " + Profile.username);
console.log("Name: " + Profile.profileName);
console.log("Posts: " + Profile.posts);
console.log("Followers: " + Profile.followers);
console.log("Following: " + Profile.following);
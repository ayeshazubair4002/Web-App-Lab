let a=5;

console.log("a++ : "+ a++);
console.log("++a : " + (++a));
console.log("a-- : "+ a--);
console.log("--a : " + (--a));

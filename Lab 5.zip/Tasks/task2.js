const Product=
{
    name: "PAK WHEELS: WATERLESS & GLASS CLEANER",
    priceBefore: 1108,
    Discount: "20%",
    priceAfter: 958,
}

console.log("Product Name: " + Product.name);
console.log("Price Before Discount: " + Product.priceBefore);
console.log("Discount: " + Product.Discount);
console.log("Price After Discount: " + Product.priceAfter);

console.log(typeof 12345n);
console.log(typeof Symbol("Symbol")); 

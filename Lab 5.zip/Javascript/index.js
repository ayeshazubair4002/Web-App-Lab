console.log("Ayesha");

fullname="Juice";
age=10;
price=99.99;
radius=14;
a=null;
y=undefined;
console.log(fullname);
console.log(price);
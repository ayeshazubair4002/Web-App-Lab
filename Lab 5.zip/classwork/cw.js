/* variables */

fullname="Ayesha Zubair";
age=21;
y=undefined;
console.log(fullname);
console.log(age);

/* var  */

var name="Ayesha";
console.log(name);

var name="Hamna";
console.log(name);

name="Sara";
console.log(name);


if (true) 
{
    var test = "Inside block";
}
console.log(test); // Output: Inside block (not block-scoped) 

/* let */

let age1=21;
console.log(age1);

age1=1;
console.log(age1);

if(true)
{
    let insideBlock="HIIIIIIIIII";
    console.log(insideBlock);
}

//console.log(insideBlock); 

/* const */

const pi=3.1416;
console.log(pi);

//pi=3.14;
//console.log(pi);

if(true)
{
    const city="Islamabad";
    console.log(city);
}

//console.log(city);

/* operators */

let a=10;
let b=5;

console.log("Addition: "+ (a+b));
console.log("Subtraction: " + (a-b));
console.log("Multiplication: " + (a*b));
console.log("Division: " + (a/b));
console.log("Modulus: " + (a%b));


/* conditional statements */

let marks=90;
if(marks>=90)
{
    console.log("Pass");
}
else
{
    console.log("Fail");
}

/* for loop */

for (let i=0;i<5;i++)
{
    console.log("Iteration:" + i);
}

/* objects */

const product=
{
    pname:"Juice",
    pprice: 50,     
    isAvailable: true,
}

console.log("Name:" + product.pname);
console.log("Price:" +  product["pprice"]);
console.log("Availability: " + product.isAvailable);

product["pname"]= "chips";
console.log(product.pname);


/* Unary Operators */

let a1=5;
let b1=2;
console.log("a= ", a1,  "& b= ", b1);

console.log("a++ = ", a1++);
console.log("a1 = " , a1++);

/* Conditional operators */

/*if(5*2==10)
{
    console.log("Your answer is correct!");
}
else
{
    console.log("Your answer is incorrect");
}*/

//Q:Ask user to enter time and check if its morning,evening or night?

/*var time= prompt("Enter time:");

if(time>5 && time < 17)
{
    alert("Good Morning!");
}
else
{
    console.log("Good Evening!");
} */

/* switch */

var fruit= prompt("Which fruit do you want?");

switch(fruit)
{
    case "Bananas":
        console.log("Here are your bananas!");
        break;
    
    case "Apples":
        console.log("Here are your apples!");
        break;

    case "Strawberry":
        console.log("Here are your strawberries!");
        break;

    default:
        console.log("Fruit unavailable");
        break;

}

/* for in loop */

const person1 =
{
    fname:"John", 
    lname:"Doe", 
    age:25
};

let text = "";
for (let x in person1) {
  text += person1[x] + " ";
}

console.log(text);

/* for of loop */

const cars = ["BMW", "Volvo", "Mini"];
let text1 = "";
for (let x of cars) 
{
  text1 += x + " " ;
}

console.log(text1);

/* type of */

let n1=10;
console.log(typeof n1);

let n2=10.5;
console.log(typeof n2);

let n3="Hello";
console.log(typeof n3);


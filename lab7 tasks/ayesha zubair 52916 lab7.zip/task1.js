

let heading = document.getElementById("H1");

let textNode = document.createTextNode(" - Ayesha Zubair, 52916");

heading.append(textNode);

console.log(heading);

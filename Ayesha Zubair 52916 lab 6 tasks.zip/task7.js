let array=[2,3,4,5,6];

console.log("Original array:")
for(let num of array)
{
    console.log(num);
}

console.log("\n")
console.log("Squares: ")


array.forEach(function findsquare(valNum)
{
    console.log(valNum*valNum);
});


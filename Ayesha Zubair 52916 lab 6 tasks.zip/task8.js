let array=[51,90,80,45,60,30];

console.log("Original array:")
for (let text1 of array)
{
    console.log(text1);
}

console.log("\n");

console.log("Filtering out marks greater than 50:")

let marksGreater= array.filter((marks) =>
{
    return marks>50;
});

console.log(marksGreater);
/* uppercase */

let array=["dumplings","pasta","alfredo","fries","burger"];

for(let text of array)
{
    
    console.log(text.toUpperCase());
}
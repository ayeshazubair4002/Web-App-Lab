/* min and max from array */

let array=[2,6,8,90,1,0,-10,11];
let min=array[0];
let max=array[0];

for(let num of array)
{
    if(num<min)
    {
        min=num;
    }

    if(num>max)
    {

        max=num;
    }
}

console.log("Smallest: " + min  );
console.log("Largest: " + max );

let array=[1,2,3,4,5,6,7,8,9,10];
console.log("Original Array");

for(let text of array)
{
    console.log(text);
}

console.log("\n");
console.log("Product of array:");


const product=array.reduce((res , curr) =>
{
    return res*curr;
});

console.log(product);
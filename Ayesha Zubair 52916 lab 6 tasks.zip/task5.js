// number of vowels in string


function countVowels(s)
{
    let count=0;

    for(let countV of s)
    {
        if (countV == 'a' || countV == 'e' || countV == 'i' || countV == 'o' || countV == 'u'||
         countV == 'A' || countV == 'E' || countV == 'I' || countV == 'O' || countV == 'U' )
         count++;
    }
    return count;
}

let Result=countVowels("Ayesha");

console.log("Vowels in string are: "+ Result);